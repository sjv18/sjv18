package com.example.springbootvazifa1.repository;


import com.example.springbootvazifa1.entity.Xodim;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BoshqaruvRepository extends JpaRepository<Xodim,Long> {

}
