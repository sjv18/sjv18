package com.example.springbootvazifa1.service;

import com.example.springbootvazifa1.entity.Mijoz;
import com.example.springbootvazifa1.repository.MijozlarRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.Set;

@Service
public class MijozlarService {
   private final MijozlarRepository mijozlarRepository;

    public MijozlarService(MijozlarRepository mijozlarRepository) {
        this.mijozlarRepository = mijozlarRepository;
    }
    public Mijoz save(Mijoz mijoz){
        return mijozlarRepository.save(mijoz);
    }
    public void updete(Long id, Mijoz mijoz1){
        Mijoz mijoz=mijozlarRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + id));
        mijoz.setId(id);
        mijoz.setAdres(mijoz1.getAdres());
        mijoz.setXodim(mijoz1.getXodim());
        mijoz.setDate(mijoz.getDate());
        mijoz.setPasport(mijoz.getPasport());
         mijozlarRepository.save(mijoz);
    }
    public ResponseEntity<Mijoz> findById(Long id) {
        Optional<Mijoz> byId = mijozlarRepository.findById(id);
        if (byId.isPresent()) {
            return ResponseEntity.ok(byId.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    public void delte(Long id){

        mijozlarRepository.deleteById(id);
    }
    public ResponseEntity<Set<Mijoz>> finByXodimId(Long id){
        return ResponseEntity.ok(mijozlarRepository.findAllByXodimId(id));
    }
}
