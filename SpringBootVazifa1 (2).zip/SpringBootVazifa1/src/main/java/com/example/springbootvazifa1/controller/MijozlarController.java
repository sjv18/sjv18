package com.example.springbootvazifa1.controller;

import com.example.springbootvazifa1.entity.Mijoz;
import com.example.springbootvazifa1.service.MijozlarService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;

@RestController
@RequestMapping("/api")
public class MijozlarController {
    private final MijozlarService mijozlarService;

    public MijozlarController(MijozlarService mijozlarService) {
        this.mijozlarService = mijozlarService;
    }

    @PostMapping("/mijozlar")
    public ResponseEntity saveMijoz(@RequestBody Mijoz mijoz){
        return ResponseEntity.ok(mijozlarService.save(mijoz));
    }
    @PutMapping("/mijozlar")
    public void updeteMijoz(@RequestParam Long id,@RequestBody Mijoz mijoz){
        mijozlarService.updete(id,mijoz);
    }
    @GetMapping("/mijozlar/{id}")
    public ResponseEntity getByID(@RequestParam Long id){
        Mijoz reult= mijozlarService.findById(id).getBody();
        return ResponseEntity.ok(reult);
    }
    @DeleteMapping("/mijozlar")
    public void arxiv(@RequestParam Long id){
       mijozlarService.delte(id);
    }
    @GetMapping("/mijozlar")
    public ResponseEntity<Set<Mijoz>> finByXodimId(@RequestParam Long id){
        Set<Mijoz> result= (Set<Mijoz>) mijozlarService.finByXodimId(id);
        return ResponseEntity.ok(result);
    }
}
